// Este flujo de Genkit se ha dejado intencionalmente en blanco o mínimo
// según la solicitud del usuario para revertir la funcionalidad anterior.
'use server';

/**
 * @fileOverview Flujo de generación de imágenes deshabilitado.
 */

// Para mantener la estructura