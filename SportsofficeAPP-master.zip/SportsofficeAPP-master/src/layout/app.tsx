'use client';
import React from 'react';


export function Body({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      {children}

    </>
  );
}
