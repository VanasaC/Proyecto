
export const HOURLY_RATE_CATEGORIES: string[] = [
  'Profesores',
  'Entrenador Personal',
  'Fotografía',
  'Instalación Deportiva',
  'Contratista', // Added Contratista
];
